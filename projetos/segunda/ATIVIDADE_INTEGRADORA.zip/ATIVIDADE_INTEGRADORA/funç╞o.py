roda()

while escolha != 1 and escolha != 2 and escolha != 3:
    print("escolha uma opção valida")
    escolha = int(input("Digite a opção desejada: "))