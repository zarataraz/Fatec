print("Menu de opções: \n 1- Cadastrar \n 2- Exibir frase \n 3- Sair")
escolha = int(input("Digite a opção desejada: "))

while escolha != 1 and escolha != 2 and escolha != 3:
    print("escolha uma opção valida")
    escolha = int(input("Digite a opção desejada: "))

if escolha = 1



